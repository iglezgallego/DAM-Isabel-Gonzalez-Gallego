//Cuando se cargue el botón del HTML
document.addEventListener("DOMContentLoaded", function() {
    var boton = document.getElementById("pulsame");
    var originalText = boton.innerHTML;
    boton.addEventListener("click", function() {
        // Agrega una clase CSS al botón para darle animación
        boton.classList.add("animation");

        // Cambia el texto del botón
        boton.innerHTML = "Ahora me puedo mover";

        // Elimina la clase CSS después de 2 segundos para detener la animación
        setTimeout(function() {
            boton.classList.remove("animation");
            boton.innerHTML = originalText;
        }, 2000);
    });
});